while True:
    print(f'Menu: ')
    print(f'1 - Cadastrar')
    print(f'2 - Consultar')
    print(f'3 - Sair')

    opcao = input("Escolha uma opção: ")

    if opcao == "Cadastrar" or opcao == '1':
        print("Cadastrado")

    elif opcao == "Consultador" or opcao == '2':
        print("Consultado")

    elif opcao == "Sair" or opcao == '3':
        print("Saindo... ")
        break

    else:
        print(f'Escolha uma das opções informadas')
